from django import forms

# 'ageLV': [45],
#    'onMMD': [0],
#    'Gender_Female': [0],
#    'Gender_Male': [1],
#    'VL_Category_0-49': [0],
#    'VL_Category_1000+': [1],
#    'VL_Category_200-999': [0],
#    'VL_Category_50-199': [0],
#    'County_KIAMBU': [0] ,
#    'County_KIRINYAGA': [1] ,
#    'County_LAIKIPIA': [0],
#    'County_MURANGA': [0],
#    'County_NYANDARUA': [0],
#    'County_NYERI': [1],


COUNTIES = [
    ('KIAMBU', 'KIAMBU'),
    ('KIRINYAGA', 'KIRINYAGA'),
    ('LAIKIPIA', 'LAIKIPIA'),
    ('MURANGA', 'MURANGA'),
    ('NYANDARUA', 'NYANDARUA'),
    ('NYERI', 'NYERI'),
]
GENDERS = [
    ('Female', 'Female'),
    ('Male', 'Male'),
]
VLS = (
    ('0-49', '0-49'),
    ('1000+', '1000+'),
    ('200-999', '200-999'),
    ('50-199', '50-199')
)


class PredictionForm(forms.Form):
    age = forms.IntegerField()
    County = forms.ChoiceField(choices=COUNTIES)
    Gender = forms.ChoiceField(choices=GENDERS)
    VL_Category = forms.ChoiceField(choices=VLS)
    onMMD = forms.BooleanField(required=False)
