from django.conf import settings
from django.http import QueryDict
from django.shortcuts import render
import joblib
from django.views.generic import View
import pandas as pd
from .forms import VLS, GENDERS, COUNTIES
import json
from core.forms import PredictionForm
from sklearn.preprocessing import StandardScaler


# Create your views here.
# 'onMMD': [1] if request.POST.get('onMMD') else [0],
#             f'Gender_{gender_tuple[0]}': [] for gender_tuple in GENDERS,
#             'Gender_Female': [1] if request.POST.get('Gender') == 'Female' else [0],
#             'Gender_Male': [1] if request.POST.get('Gender') == 'Male' else [0],

class PredictionView(View):
    def get(self, request, *args, **kwargs):
        form = PredictionForm()
        return render(request, 'prediction.html', {'form': form})

    def post(self, request, *args, **kwargs):
        data = {
            'ageLV': [int(request.POST.get('age'))],
            'onMMD': [1] if request.POST.get("onMMD", None) is not None else [0]
        }
        data.update(
            {
                f'Gender_{gender_tuple[0]}': [1] if request.POST.get("Gender") == gender_tuple[0] else [0] for
                gender_tuple
                in GENDERS}
        )
        data.update(
            {
                f'VL_Category_{vl_tuple[0]}': [1] if request.POST.get("VL_Category") == vl_tuple[0] else [0] for
                vl_tuple
                in VLS}
        )
        data.update(
            {
                f'County_{C_tuple[0]}': [1] if request.POST.get("County") == C_tuple[0] else [0] for
                C_tuple
                in COUNTIES}
        )
        df = {'ageLV': [45],
              'onMMD': [0],
              'Gender_Female': [0],
              'Gender_Male': [1],
              'VL_Category_0-49': [0],
              'VL_Category_1000+': [1],
              'VL_Category_200-999': [0],
              'VL_Category_50-199': [0],
              'County_KIAMBU': [0],
              'County_KIRINYAGA': [0],
              'County_LAIKIPIA': [0],
              'County_MURANGA': [0],
              'County_NYANDARUA': [0],
              'County_NYERI': [1],
              }
        print(data == df)
        # print(json.dumps(data, indent=3))
        form = PredictionForm(initial=request.POST)
        # print(pd.DataFrame(data))
        prediction = True if self.predict(pd.DataFrame(data))[0] == 1 else False

        return render(request, 'prediction.html', {'form': form,
                                                   'prediction': prediction
                                                   })

    def predict(self, features: pd.DataFrame):
        scaler = joblib.load(settings.SCALAR_PATH)
        df_scaled = scaler.transform(features.values)
        model = joblib.load(settings.MODEL_PATH)
        predictions = model.predict(df_scaled)
        return predictions
